import akka.NotUsed
import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.headers.RawHeader
import akka.http.scaladsl.model.{HttpMethods, HttpRequest, HttpResponse}
import akka.http.scaladsl.unmarshalling.Unmarshal
import scala.io.StdIn
import akka.stream.scaladsl.{Sink, Source}
import scala.util.{Failure, Success}


object Main extends App{
  implicit val as = ActorSystem()
  implicit val ec = as.dispatcher

  println("How many fox images?")
  val fox = StdIn.readInt()

  // Create a sequence of HTTP requests for Chuck Norris API
  val foxRequests = Seq.fill(fox)(HttpRequest(
    method = HttpMethods.GET,
    uri = "https://randomfox.ca/floof/?ref=apilist.fun",
    headers = Seq(
      RawHeader("Content-Type", "application/json"),
      RawHeader("Accept", "application/json")
    )
  ))
  val processingFut = Source(foxRequests.toVector.map((_, NotUsed)))
    .via(Http().superPool[NotUsed]())
    .map {
      case (Success(response), _) => response
      case (Failure(err), _) => throw err
    }
    .mapAsyncUnordered(10)(resp => Unmarshal(resp.entity).to[String].map((_, resp)))
    .map {case (body, resp) =>
      resp.entity.discardBytes()
      body
    }
    .runWith(Sink.seq)
  processingFut.map(println).andThen(_ => as.terminate())
}
